package com.fashionopt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FashionoptApplication {

	public static void main(String[] args) {
		SpringApplication.run(FashionoptApplication.class, args);
	}

}
